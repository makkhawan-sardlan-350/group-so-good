﻿namespace snake
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            pbcanvas = new PictureBox();
            lblscore = new Label();
            lblgameover = new Label();
            gametimer = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)pbcanvas).BeginInit();
            SuspendLayout();
            // 
            // pbcanvas
            // 
            pbcanvas.BackColor = Color.FromArgb(255, 255, 192);
            pbcanvas.Location = new Point(12, 12);
            pbcanvas.Name = "pbcanvas";
            pbcanvas.Size = new Size(635, 437);
            pbcanvas.TabIndex = 0;
            pbcanvas.TabStop = false;
            pbcanvas.Paint += pbcanvas_Paint;
            // 
            // lblscore
            // 
            lblscore.AutoSize = true;
            lblscore.BackColor = SystemColors.Control;
            lblscore.Font = new Font("Segoe UI", 15F);
            lblscore.ForeColor = Color.Blue;
            lblscore.Location = new Point(683, 88);
            lblscore.Name = "lblscore";
            lblscore.Size = new Size(65, 28);
            lblscore.TabIndex = 1;
            lblscore.Text = "คะแนน";
            // 
            // lblgameover
            // 
            lblgameover.AutoSize = true;
            lblgameover.BackColor = SystemColors.Control;
            lblgameover.Font = new Font("Segoe UI", 9F);
            lblgameover.ForeColor = Color.Red;
            lblgameover.Location = new Point(32, 29);
            lblgameover.Name = "lblgameover";
            lblgameover.Size = new Size(38, 15);
            lblgameover.TabIndex = 2;
            lblgameover.Text = "label2";
            lblgameover.TextAlign = ContentAlignment.MiddleCenter;
            lblgameover.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(784, 461);
            Controls.Add(lblgameover);
            Controls.Add(lblscore);
            Controls.Add(pbcanvas);
            Name = "Form1";
            Text = "Form1";
            KeyDown += Form1_KeyDown;
            KeyUp += Form1_KeyUp;
            ((System.ComponentModel.ISupportInitialize)pbcanvas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pbcanvas;
        private Label lblscore;
        private Label lblgameover;
        private System.Windows.Forms.Timer gametimer;
    }
}
