namespace snake
{
    public partial class Form1 : Form
    {
        private List<Circle> Snake = new List<Circle>();
        private Circle food = new Circle();

        public Brush SnakeConlour { get; private set; }

        public Form1()
        {
            InitializeComponent();

            new setting();

            gametimer.Interval = 1000 / setting.Speed;
            gametimer.Tick += updatescreen;
            gametimer.Start();

            startgame();

        }

        private void startgame()
        {
            lblgameover.Visible = false;
            new setting();
            Snake.Clear();
            Circle head = new Circle { x = 10, y = 5 };
            Snake.Add(food);

            lblscore.Text = setting.Score.ToString();
            generatefoob();
        }

        private void generatefoob()
        {
            int maxXPos = pbcanvas.Size.Width / setting.Width;
            int maxYPos = pbcanvas.Size.Height / setting.Height;

            Random random = new Random();
            food = new Circle { x = random.Next(0, maxXPos), y = random.Next(0, maxYPos) };
        }

        private void updatescreen(object sender, EventArgs e)
        {
            if (setting.GameOver)
            {
                if (input.KeyPressed(Keys.Enter))
                {
                    startgame();
                }
            }
            else
            {
                if (input.KeyPressed(Keys.Right) && setting.direction != Direction.Left)
                    setting.direction = Direction.Right;
                else if (input.KeyPressed(Keys.Left) && setting.direction != Direction.Right)
                    setting.direction = Direction.Left;
                else if (input.KeyPressed(Keys.Up) && setting.direction != Direction.Down)
                    setting.direction = Direction.Down;
                else if (input.KeyPressed(Keys.Down) && setting.direction != Direction.Up)
                    setting.direction = Direction.Up;
                moveplayer();
            }
            pbcanvas.Invalidate();
        }

        private void pbcanvas_Paint(object sender, PaintEventArgs e)
        {
            Graphics canvas = e.Graphics;
            if (!setting.GameOver)
            {
                for (int i = 0; i < Snake.Count; i++)
                {
                    Brush SnakeColour;
                    if (i == 0)
                        SnakeColour = Brushes.Brown;
                    else
                        SnakeColour = Brushes.Gold;
                    canvas.FillEllipse(SnakeColour,
                        new Rectangle(Snake[i].x * setting.Width,
                        Snake[i].y * setting.Height,
                        setting.Width, setting.Height));

                    canvas.FillEllipse(Brushes.Red,
                        new Rectangle(food.x * setting.Width,
                        food.y * setting.Height, setting.Width, setting.Height));
                }
            }
            else
            {
                string gameOver = "Game over \nYour final score is: " + setting.Score + "\nProess Enter to try again";
                lblgameover.Text = gameOver;
                lblgameover.Visible = true;
            }
        }

        private void moveplayer()
        {
            for (int i = Snake.Count - 1; i >= 0; i--)
            {
                if (i == 0)
                {
                    switch (setting.direction)
                    {
                        case Direction.Right:
                            Snake[i].x++;
                            break;
                        case Direction.Left:
                            Snake[i].x--;
                            break;
                        case Direction.Up:
                            Snake[i].y++;
                            break;
                        case Direction.Down:
                            Snake[i].y--;
                            break;
                    }

                    int maxXPos = pbcanvas.Size.Width / setting.Width;
                    int maxYPos = pbcanvas.Size.Height / setting.Height;

                    if (Snake[i].x < 0 || Snake[i].y < 0
                        || Snake[i].x >= maxXPos || Snake[i].y >= maxYPos
                    )
                    {
                        die();
                    }

                    if (Snake[0].x == food.x && Snake[0].y == food.y)
                    {
                        eat();
                    }
                }
                else
                {
                    Snake[i].x = Snake[i - 1].x;
                    Snake[i].y = Snake[i - 1].y;
                }
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            input.ChangeState(e.KeyCode, true);
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            input.ChangeState(e.KeyCode, false);
        }

        private void eat()
        {
            Circle circle = new Circle
            {
                x = Snake[Snake.Count - 1].x,
                y = Snake[Snake.Count - 1].y,
            };
            Snake.Add(circle);

            setting.Score += setting.Points;
            lblscore.Text = setting.Score.ToString();

            generatefoob();
        }

        private void die()
        {
            setting.GameOver = true;
        }
    }
}
