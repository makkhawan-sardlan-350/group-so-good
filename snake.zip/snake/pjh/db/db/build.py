import barcode
from barcode.writer import ImageWriter
from pyzbar.pyzbar import decode
import cv2
import os
import random

EAN13 = barcode.get_barcode_class('ean13')

number = str(random.randint(111111111111,999999999999))

while True:
    if not os.path.exists(str(number)):
        number = str(random.randint(111111111111,999999999999))
        break

my_ean = EAN13(number, writer=ImageWriter())

filename = my_ean.save(str(number))

print(f"Barcode saved as: {filename}")

image = cv2.imread(filename)

if image is None:
    print("Could not open the image file!")
else:
    detected_barcodes = decode(image)

    for barcode in detected_barcodes:
        print(f"Number: {barcode.data.decode('utf-8')}")
