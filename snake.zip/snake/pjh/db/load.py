import sqlite3
import pandas as pd
import customtkinter as ctk
import os
from tkinter import filedialog

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

root_dir = os.path.dirname(__file__)

def select_file():
    file_path = filedialog.askopenfilename(
        title="Select a File",
        filetypes=[("img files", "*.png")]
    )
    
    if file_path:
        path_texbox.insert("0.0",file_path)
        print(f"File selected: {file_path}")

def load(code,root_dir):
    print(len(code))
    if len(code) != 14:
        return
    try:
        code = int(code)
    except Exception:
        print("error")
        return
    
    conn = sqlite3.connect(f'{root_dir}\\db\\code.db')
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM product WHERE id = ?", (code,))

    rows = cursor.fetchall()
    
    ck_load.configure(state="normal")
    
    row = rows[0]
    
    if rows != []:
        ck_load.insert("0.0", f"id : {row[0]}\n")
        ck_load.insert("end", f"name : {row[1]}\n")
        ck_load.insert("end", f"type : {row[2]}\n")
        ck_load.insert("end", f"money : {row[3]}\n")
    
    conn.close()
    
    ck_load.configure(state="disabled")

root = ctk.CTk()
root.title("load_barcode")
root.geometry("400x240")

path_texbox = ctk.CTkTextbox(root, text="Add File")
path_texbox.pack(pady=20)

btn = ctk.CTkButton(root, text="Add File", command=select_file)
btn.pack(pady=20)

load_button = ctk.CTkButton(root,text="load",command= lambda : load(path_texbox.get("0.0", "end"),root_dir))
load_button.pack(padx=5, pady=5)

ck_load = ctk.CTkTextbox(root,width=250,height=250)
ck_load.configure(state="disabled")
ck_load.pack(padx=5, pady=5)

root.mainloop()