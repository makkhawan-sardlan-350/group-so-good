from colorama import Fore, Style
import os
from .exr import *

def run(command):
    if command == "clear":
        os.system("cls")
        return True
    if command == "ck":
        check()
        return True
    if command.startswith("git"):
        git_ce(command)
        return True
    if command.startswith("pj"):
        command_project(command)
        return True
    if command.startswith("update"):
        update_command(command)
        return True
    return False