# import
import sys
import os
import home
# var
root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
home_dir = os.path.join(root_dir, "home")
# funtion

def main(home_dir):
    if not os.path.exists(home_dir):
        print(f"Creating home directory at {home_dir}")
        os.makedirs(home_dir, exist_ok=True)

def add_user(home_dir, username):
    home.user.add(username, home_dir)
    return 0

def remove_user(home_dir,username):
    home.user.remove(username,home_dir)
    return 0

def access_user(home_dir,username):
    home.user.access(username,home_dir)
    return 0

# run
if __name__ == "__main__":
    main(home_dir)
    if len(sys.argv) != 3:
        sys.exit(0)
    if sys.argv[1] == "--add-user":
        sys.exit(add_user(home_dir,sys.argv[2]))
    elif sys.argv[1] == "--remove-user":
        sys.exit(remove_user(home_dir,sys.argv[2]))
    elif sys.argv[1] == "--access-user":
        sys.exit(access_user(home_dir,sys.argv[2]))