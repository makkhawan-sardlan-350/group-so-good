
import os
import shutil

def add(name,home_dir):
    user_path = os.path.join(home_dir, name)
    if not os.path.exists(user_path):
        os.makedirs(user_path, exist_ok=True)
        print(f"User '{name}' created at {user_path}")
    else:
        print(f"User '{name}' already exists at {user_path}")

def remove(name,home_dir):
    user_path = os.path.join(home_dir, name)
    if os.path.exists(user_path):
        shutil.rmtree(user_path)
        print(f"User '{name}' removed from {user_path}")
    else:
        print(f"User '{name}' does not exist at {user_path}")

def access(name,home_dir):
    user_path = os.path.join(home_dir, name)
    if os.path.exists(user_path):
        os.startfile(user_path)
        print(f"User '{name}' access from {user_path}")
    else:
        print(f"User '{name}' does not exist at {user_path}")
