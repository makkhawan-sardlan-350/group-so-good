

from colorama import Style, Fore, Back
import base64
import pickle
import os
import json
import platform
import tkinter as tk
from tkinter import messagebox

name_os = platform.system()

framework_name = ""

def framework_get():
    global framework_name
    return framework_name

def framework(fw):
    global framework_name
    framework_name = fw

def compress(paths, setup={}, exr={}):
    global framework_name
    if framework_name == "JZ1.0":
        data = {
            "exr": exr,
            "path" : {}
        }
        for path in paths:
            if not os.path.isdir(path):
                print(f"Path does not exist or is not a directory: {path}")
                continue
            for root, dirs, files in os.walk(path, topdown=False):
                root_safe = os.path.relpath(root, os.path.dirname(path)).replace("\\", "/")
                if setup.get("savedir", True):
                    for dir in dirs:
                        print(f"Encoding directory: {root_safe}/{dir}")
                        data["path"][f"{root_safe}/{dir}"] = {
                            "type": "directory"
                        }
                for file in files:
                    with open(os.path.join(root, file), 'rb') as f:
                        content = f.read()
                        print(f"Encoding file: {root_safe}/{file}")
                        data["path"][f"{root_safe}/{file}"] = {
                            "type": "file",
                            "content": content
                        }


        with open(f'{path}.jzip', 'wb') as encoded_file:
            pickle.dump(data, encoded_file)
    else:
        print(Fore.RED + "Error: Unsupported framework." + Style.RESET_ALL)
        if setup.get("use_gui", False):
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror("Error", "Unsupported framework.")

def extract(path, output_dir=None):
    global framework_name
    if framework_name == "JZ1.0":
        with open(path, 'rb') as encoded_file:
            data = pickle.load(encoded_file)
        
        if output_dir:
            path = output_dir
        else:
            path = os.path.dirname(path)

        for index, info in data["path"].items():
            if info["type"] == "directory":
                if index == ".":
                    index = ""
                if name_os == "Windows":
                    index = index.replace("/", "\\")
                
                index = os.path.join(path, index)
                
                os.makedirs(index, exist_ok=True)
                print(f"Decoding directory: {index}")
            elif info["type"] == "file":
                if index == ".":
                    index = ""
                if name_os == "Windows":
                    index = index.replace("/", "\\")
                
                index = os.path.join(path, index)
                
                os.makedirs((os.path.dirname(index)), exist_ok=True)
                with open(index, 'wb') as f:
                    f.write(info["content"])
                print(f"Decoding file: {index}")
        return data["exr"]
    else:
        print(Fore.RED + "Error: Unsupported framework." + Style.RESET_ALL)
        return None
