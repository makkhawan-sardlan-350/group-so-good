import requests
import sys
import os
import json
from pathlib import Path

root_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
opt_dir = os.path.join(os.path.join(root_dir, "opt"), "pkg-data")

if len(sys.argv) == 5:
    if sys.argv[1] == "-S":
        data = {
            "name" : sys.argv[2],
            "url" : sys.argv[3],
            "surname" : sys.argv[4],
        }
        with open(f"{os.path.join(opt_dir,sys.argv[2])}.json", mode="w") as f:
            json.dump(data,f)
elif len(sys.argv) == 3:
    if sys.argv[1] == "-I":
        if not os.path.exists(f"{os.path.join(opt_dir,sys.argv[2])}.json"):
            print("Don't have pkg")
            sys.exit()
        with open(f"{os.path.join(opt_dir,sys.argv[2])}.json", mode="r") as f:
            data = json.load(f)
        home = Path.home()
        request = requests.get(data["url"])
        path_downloads = os.path.join(home,"Downloads")
        if request.status_code != 200:
            print(f"200 != {request.status_code} << status_code")
            sys.exit(0)
        file_name = os.path.join(os.path.join(home,"Downloads"),f"{data["name"]}.{data["surname"]}")
        if os.path.exists(file_name):
            print("Have file")
            sys.exit()
        with open(file_name,mode="wb") as f:
            f.write(request.content)

print("Done")
